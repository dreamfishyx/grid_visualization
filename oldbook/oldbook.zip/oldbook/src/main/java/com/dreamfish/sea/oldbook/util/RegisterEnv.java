package com.dreamfish.sea.oldbook.util;

/**
 * @author Dream fish
 * @version 1.0
 * @description: jsr303校验分组
 * @date 2023/11/13 14:45
 */
public interface RegisterEnv {
}
